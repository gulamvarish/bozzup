<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package wpbstarter
 */

 if(!is_page_template( 'blank-page.php' ) && !is_page_template( 'blank-page-with-container.php' )&& !is_page_template( 'fullwidth-nocontainer-noheading.php' )): ?>

	</div><!-- #content -->

    <?php get_template_part( 'footer-widget' ); ?>
	<footer id="colophon" class="site-footer">
		<div class="site-info">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 d-flex justify-content-center justify-content-md-start">
						<a href="<?php echo home_url(); ?>">
							<?php
							 echo "&copy; Copyright 2021, BozzUp";
							?>
						</a>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 d-flex justify-content-center justify-content-md-end">
						<small class="float-right"> Design & Developed by <a href="https://www.tecziq.com" target="_blank"> Tecziq Solutions Pvt. Ltd. </a></small>
					</div>
				</div>
			</div>


		</div><!-- .site-info -->
	</footer><!-- #colophon -->
<?php endif; ?>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
