<?php
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );
function my_theme_enqueue_styles() {
    $parenthandle = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
    $theme = wp_get_theme();
    wp_enqueue_style( $parenthandle, get_template_directory_uri() . '/style.css', 
        array(),  // if the parent theme code has a dependency, copy it to here
        $theme->parent()->get('Version')
    );

    wp_enqueue_style( 'twitter-bootstrap-css', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css');
    wp_enqueue_style( 'datatables-css', 'https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css');    
    wp_enqueue_style( 'dataTables-responsive-css', 'https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap4.min.css');

    wp_enqueue_style( 'child-style', get_stylesheet_uri(),
        array( $parenthandle ),
        $theme->get('Version') // this only works if you have Version in the style header
    );

}
/*Added By Gulam */
add_filter( 'wp_new_user_notification_email', 'custom_wp_new_user_notification_email', 10, 3 );
function custom_wp_new_user_notification_email( $wp_new_user_notification_email, $user, $blogname ) { 
    $user_login = stripslashes( $user->user_login );
    $user_login = stripslashes( $user->user_login );
    $user_email = stripslashes( $user->user_email );
    $login_url  = wp_login_url();
    $key        = get_password_reset_key( $user );
    $message = "
                    <html>
                    <head>
                    <title>Login details email text:</title>
                    </head>
                    <body>
                    <p>Dear ". $user_login.", </p>
                    <p>We have set up an account for you on Bozzup</p>
                    <table>
                    <tr><td colspan='2'>Here's your login information:</td></tr>
                    <tr>
                    <th style='padding-left:20px'>Username:</th>
                    <td >".$user_login."</td>                    
                    </tr>
                    <tr>
                    <th style='padding-left:20px'>Password:</th>
                    <td >".$_SESSION['subscriber_pass']."</td>                    
                    </tr>
                    <tr>
                    <th style='padding-left:20px'>Reset Password:</th>
                    <td>".network_site_url( 'wp-login.php?action=rp&key='.$key.'&login=' . rawurlencode( $user->user_login ), 'login' )."</td>
                    </tr>
                    <tr><td colspan='2'>To login to your dashboard and manage your mockups, just follow the link below:</td></tr>
                    <tr>
                    <th align='left'>Login:</th>
                    <td>".home_url()."</td></tr>
                     <tr><td colspan='2'>If you ever need anything, just let us know.</tr>
                      <tr><td colspan='2'>You can always email us at Support@bozzup.net</td></tr>
                     <tr style='margin-top:15px; display: block;'><td colspan='2'> The Bozzup team</td></tr>
                      <tr><td colspan='2'>Bozzup.net</td></tr>
                    </table> 
                    </body>
                    </html>
                    ";   
 
    $wp_new_user_notification_email['subject'] = sprintf( 'Login and Password to manage your mockups', $blogname );
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: Bozzup <support@bozzup.net>'; 
    $wp_new_user_notification_email['headers'] = $headers;    
    $wp_new_user_notification_email['message'] = $message;
 
    return $wp_new_user_notification_email;
}
/*add_filter( 'login_redirect', 'login_redirect', 10, 3 );
function login_redirect( $url, $query, $user ) {

if(!is_null($user->roles[0])){
        if($user->roles[0] != 'administrator'){
          return home_url();
        } 
    } else{

    } 
}*/

function ace_block_wp_admin() {
    if ( is_admin() && ! current_user_can( 'administrator' ) && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
        wp_safe_redirect( home_url() );
        exit;
    }
}
add_action( 'admin_init', 'ace_block_wp_admin' );

// COMMENTED BY RAHUL AS CUSTOM FIELD COMPANY NAME ADDED
// add_filter( 'gettext', 'user_nickname', 10, 2 );
function user_nickname( $translation, $original )
{  
   if ( 'Nickname' == $original ) {
        return 'Company Name';}  
    return $translation;
}
/*Added By Gulam */



add_action('init', 'myStartSession', 1);
add_action('wp_logout', 'myEndSession');
add_action('wp_login', 'myEndSession');

function myStartSession() {
    if(!session_id()) {
        session_start();
    }
}

function myEndSession() {
    session_destroy ();
}

/*by rkumar 6 may 2021*/
function custom_user_profile_fields($user){
    $previous_value = '';
    if( is_object($user) && isset($user->ID) ) {
        $previous_value = get_user_meta( $user->ID, 'company', true );
    }
    ?>

    <table class="form-table">
        <tr>
            <th><label for="company">Company Name</label></th>
            <td>
                <input type="text" class="regular-text" name="company" value="<?php echo esc_attr( $previous_value ); ?>" id="company" /><br />
                <span class="description"></span>
            </td>
        </tr>
    </table>
<?php
}
add_action( 'show_user_profile', 'custom_user_profile_fields' );
add_action( 'edit_user_profile', 'custom_user_profile_fields' );
add_action( "user_new_form", "custom_user_profile_fields" );

function save_custom_user_profile_fields($user_id){

   
    $_SESSION['subscriber_pass'] =  $_POST['pass1'];
   //  echo "<pre>"; print_r($_SESSION['subscriber_pass']); die; exit;
    
    if(!current_user_can('manage_options'))
        return false;
    
    //add_action( 'user_profile_update_errors', 'crf_user_profile_update_errors', 10, 3 );

    # save my custom field
    if( isset($_POST['company']) ) {
        update_user_meta( $user_id, 'company', sanitize_text_field( $_POST['company'] ) );
    } else {
        //Delete the company field if $_POST['company'] is not set
        delete_user_meta( $user_id, 'company', $meta_value );
    }
}
add_action('user_register', 'save_custom_user_profile_fields');
add_action( 'personal_options_update', 'save_custom_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_custom_user_profile_fields' );


/*Validate company name*/
add_action( 'user_profile_update_errors', 'crf_user_profile_update_errors', 10, 3 );
function crf_user_profile_update_errors( $errors, $update, $user ) {
    if ( $update ) {
        return;
    }

    if ( empty( $_POST['company'] ) ) {
        $errors->add( 'company_error', __( '<strong>ERROR</strong>: Please enter company name.', 'crf' ) );
    }
}




/*js add in footer*/

add_action( 'wp_footer', 'my_footer_scripts' );
function my_footer_scripts(){
 
 

    wp_localize_script( 'ajax-js', 'ajax_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

       wp_enqueue_script( 'custom-js', get_stylesheet_directory_uri() . '/js/custom.js', array() );



                // Localize the script with new data
            $custom_array = array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),                
                'ajaxnounce'=>  wp_create_nonce("load_more_posts")
            );
            wp_localize_script( 'custom-js', 'custom_data', $custom_array );

            // Enqueued script with localized data.
            wp_enqueue_script( 'custom-js' );

}


/*For User data get*/

add_action( 'wp_ajax_getpostsfordatatables', 'my_ajax_getpostsfordatatables' );
add_action( 'wp_ajax_nopriv_getpostsfordatatables', 'my_ajax_getpostsfordatatables' );

function my_ajax_getpostsfordatatables() {
    global $wpdb;
      $user = wp_get_current_user();
      $user->ID;
      $rorle = $user->roles[0];

      //$sql   = "SELECT * FROM wp_users WHERE `created_by` = $user->ID";
      $query = "SELECT * FROM wp_users INNER JOIN wp_usermeta ON wp_users.ID = wp_usermeta.user_id
      WHERE wp_users.created_by = $user->ID and wp_usermeta.meta_key = 'wp_capabilities' and wp_usermeta.meta_value like '%subscriber%'
      ORDER BY wp_users.user_nicename";

     
      $users = $wpdb->get_results($query);

// Array of WP_User objects.
    $return_json = array();
    foreach ( $users as $user ) {

        $name = get_user_meta( $user->ID, 'first_name' , true ).''.get_user_meta( $user->ID, 'last_name' , true );
        $company = $company = !empty(get_user_meta( $user->ID, 'company' , true ))?get_user_meta( $user->ID, 'company' , true ):'No Added';

        $row = array(
            'id' => $user->ID,
            'username'     => $user->user_email,
            'name'         => $name,
            'email'        => $user->user_email,
            'company'      => $company,
            'addeddate'    =>  date('Y-m-d', strtotime($user->user_registered))


        );
        $return_json[] = $row;
    }



    echo json_encode(array('data' => $return_json));
    wp_die();
}


/*For Plan*/


if ( ! function_exists('plan') ) {

// Register Custom Post Type
function plan() {

    $labels = array(
        'name'                  => _x( 'Plans', 'Post Type General Name', 'bozzup' ),
        'singular_name'         => _x( 'Plan', 'Post Type Singular Name', 'bozzup' ),
        'menu_name'             => __( 'Plan', 'bozzup' ),
        'name_admin_bar'        => __( 'Post Type', 'bozzup' ),
        'archives'              => __( 'Item Archives', 'bozzup' ),
        'attributes'            => __( 'Item Attributes', 'bozzup' ),
        'parent_item_colon'     => __( 'Parent Item:', 'bozzup' ),
        'all_items'             => __( 'All Items', 'bozzup' ),
        'add_new_item'          => __( 'Add New Item', 'bozzup' ),
        'add_new'               => __( 'Add New', 'bozzup' ),
        'new_item'              => __( 'New Item', 'bozzup' ),
        'edit_item'             => __( 'Edit Item', 'bozzup' ),
        'update_item'           => __( 'Update Item', 'bozzup' ),
        'view_item'             => __( 'View Item', 'bozzup' ),
        'view_items'            => __( 'View Items', 'bozzup' ),
        'search_items'          => __( 'Search Item', 'bozzup' ),
        'not_found'             => __( 'Not found', 'bozzup' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'bozzup' ),
        'featured_image'        => __( 'Featured Image', 'bozzup' ),
        'set_featured_image'    => __( 'Set featured image', 'bozzup' ),
        'remove_featured_image' => __( 'Remove featured image', 'bozzup' ),
        'use_featured_image'    => __( 'Use as featured image', 'bozzup' ),
        'insert_into_item'      => __( 'Insert into item', 'bozzup' ),
        'uploaded_to_this_item' => __( 'Uploaded to this item', 'bozzup' ),
        'items_list'            => __( 'Items list', 'bozzup' ),
        'items_list_navigation' => __( 'Items list navigation', 'bozzup' ),
        'filter_items_list'     => __( 'Filter items list', 'bozzup' ),
    );
    $args = array(
        'label'                 => __( 'Plan', 'bozzup' ),
        'description'           => __( 'Plan', 'bozzup' ),
        'labels'                => $labels,
        'supports'              => array( 'title' ),
        'hierarchical'          => true,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 20,
        'menu_icon'             => 'dashicons-edit-page',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => false,
        'exclude_from_search'   => true,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );
    register_post_type( 'plan', $args );

}
add_action( 'init', 'plan', 0 );

}